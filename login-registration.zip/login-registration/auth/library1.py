import mysql.connector

class library:
    def __inti__(self):
        self.mydb = mysql.connector.connect(host="localhost",user="root",password="",database="mydb")    

    def fire(self,query):
        mycursor = self.mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

    def delete(self,table,field,value):
        qry="delete from " +table +" where " + field +" = '" + value + "'"
        if(self.fire(qry)):
            returnlist=['Sucessfully insert data','1']
        else:
            returnlist=['Not inserted','0']
        return returnlist

ob=library()
qry=ob.delete("sale" , "id" , "11")
print(qry)

