import mysql.connector

class library:
    def __inti__(self):
        self.mydb = mysql.connector.connect(host="localhost",user="root",password="",database="mydb")    

    def fire(self,query):
        mycursor = self.mydb.cursor()
        #mycursor.execute(sql, val)
        #mydb.commit()

#{"name":"ram","sale":5200}
    def insert(self,table,arr):
        qry=" insert into " + table +" set "
        i=1
        for key, value in arr.items():
            if(i==len(arr)):
                qry=qry + key + " = '" + value + "' "
            else:
                qry=qry + key + " = '" + value + "', "
            i=i+1
        if(self.fire(qry)):
            returnlist=['Sucessfully insert data','1']
        else:
            returnlist=['Not inserted','0']
        return returnlist
    
    def delete(self,table,field,value):
        qry="delete from " +table +" where " + field +" = '" + value + "'"
        if(self.fire(qry)):
            returnlist=['Sucessfully insert data','1']
        else:
            returnlist=['Not inserted','0']
        return returnlist


ob=library()
dic={"name":"Ram singh","sale":"5690","City":"Pali"}
qr=ob.delete("sale","id","11")
print(qr)