import mysql.connector


def connect():
	mydb = mysql.connector.connect(host="localhost",user="root",password="",database="mydb")
	return mydb
	

def insert(qry):
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	conn.commit()
	if(mycursor.rowcount>=1):
		return 1
	else:
		return 0

def check(table,field,value):
	qry="select * from " + table +" where " + field + " = '" + value + "'"
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	conn.commit()
	return mycursor.rowcount

def firequery(qry):
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	conn.commit()
	return mycursor.rowcount


def dblogin(tab,where):
	qry="select * from " + tab + where
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	conn.commit()
	return mycursor.rowcount

def getdata(table,where=""):
	if(len(where)<=5):
		qry="select * from " + table
	else:
		qry="select * from " + table + where
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	lst=mycursor.fetchall()
	return lst

def updateverfication(table,field,value,verifedField):
	qry="update " + table +" set " + verifedField + "=1 where " + field + " = '" + value + "'"
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	conn.commit()
	
	return True

def updatepass(table,field,value,id):
	qry=" update " + table +" set " + field + "= '" + value + "' where id  = '" + str(id) + "'"
	conn=connect()
	mycursor=conn.cursor(buffered=True)
	mycursor.execute(qry)
	conn.commit()
	
	return qry


	