-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2021 at 09:54 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rollno` varchar(15) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `image` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL,
  `emailVer` varchar(10) NOT NULL,
  `mobileVer` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `username`, `email`, `rollno`, `mobile`, `image`, `password`, `emailVer`, `mobileVer`) VALUES
(12, 'Ayan', 'maksoodayan2@gmail.com', '', '9587007865', 'game.png', '147', '1', '0'),
(13, 'Rashid', 'rashidkhan@gmail.com', '', '7859645123', 'safe.png', '222', '0', '0'),
(14, 'Dimple', 'dimplesotwal@gmail.com', '', '8094608129', 'photo-1494790108377-be9c29b29330.jpg', '148', '1', '0'),
(15, 'Shyam', 'shyam@gmail.com', '', '9828507862', 'depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg', '1478', '0', '0'),
(16, 'Gyanu', 'gyanu@gmail.com', '19EJDAI023', '6587453652', 'profile_user.jpg', '1223', '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
