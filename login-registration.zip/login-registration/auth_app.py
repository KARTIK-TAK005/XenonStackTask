from flask import Flask, request, render_template,url_for,session, make_response
from flask_recaptcha import ReCaptcha
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename
from library import *
import random
import urllib.request as urllib
import requests
from flask_bcrypt import Bcrypt


app = Flask(__name__)
bcrypt = Bcrypt(app)
app.secret_key = 'kjfhdskjfh sfkjshd'

#email configration code
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'dimplesotwal@gmail.com'
app.config['MAIL_PASSWORD'] = 'dimple8129@'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)



#Captha  Capcha  code
recaptcha = ReCaptcha(app=app)
app.secret_key="kjhkjhjgyfuy"
app.config.update(dict(
    RECAPTCHA_ENABLED=True,
    RECAPTCHA_SITE_KEY="6LfJ1TwaAAAAAGLFyzUg6Qc7ODUbPYc6w0Eljg4-",
    RECAPTCHA_SECERT_KEY="6LfJ1TwaAAAAAH9Lm7pYWneev4W_W9Mi-8mcR_89",
))
recaptcha.init_app(app)



@app.route('/')
def login():
    if(request.cookies.get('email')):
        return render_template("home.html")
    else:
        return render_template('login.html') 


@app.route('/home')
def home():
    render_template('home.html')


@app.route('/verifyEmail')
def verifyEmail():
    verifycode=random.randint(111111,999999)
    session['code']=verifycode
    message=" Your email verfication code is " + str(verifycode)
    rece=session['email']
    sender='dimplesotwal@gmail.com'
    msg = Message("Verification Email code", sender =sender, recipients = [rece])
    msg.body = message
    mail.send(msg)
    return render_template('verifyEmail.html')


@app.route('/verifymob')
def verifymobile():
    verifycode=random.randint(111111,999999)
    session['mob_code']=verifycode
    message=" Your Verification Code is " + str(verifycode) + " it is only Valid for two Hour Sender Ayan Maksood"
    mob=session['mobile']
    id='AYANMK'
    response=requests.get("http://new.rajbusiness.com/api/mt/SendSMS?user=VATSAA&password=VATSAA259&senderid=" + id + "&channel=Trans&DCS=0&flashsms=0&number=" + mob + "&text=" + message + "&route=01")
    if(not(response)):
        error="Mobile messagge is not send Please Contact to Administration of this website"
        return render_template('home.html',err=error)
    else:
        return render_template('mobileCode.html')
    

@app.route("/codeVerfi",methods=['GET', 'POST'])
def codeVerfi():
    if(request.method=="POST"):
        textcode=request.form['xcode']
        if(str(textcode)==str(session['code'])):
            if(updateverfication("member","email",session['email'],"emailVer")):
               session['emailVer']="1"
               error="Sucessfully Verified"
            else:
                error="Still not Verify your email"
                
            return render_template("home.html",err=error)
        else:
            error="Verification Code is not Match. Please try again"
            return render_template("verifyemail.html",err=error)

@app.route("/mobcodever",methods=['GET', 'POST'])
def mobilecodeVerfi():
    if(request.method=="POST"):
        mobcode=request.form['ncode']
        if(str(mobcode)==str(session['mob_code'])):
            if(updateverfication("member","mobile",session['mobile'],"mobileVer")):
               session['mobileVer']="1"
               error="Sucessfully Verified"
            else:
                error="Still not Verify your email"
                
            return render_template("home.html",err=error)
        else:
            error="Verification Code is not Match. Please try again"
            return render_template("mobileCode.html",err=error)




@app.route('/register')
def registration():
    return render_template("registration.html")

@app.route('/logout')
def logout():
    session.pop('email', None)
    session.pop('login', None)
    resp = make_response(render_template('login.html'))
    resp.set_cookie('email','',expires=0)
    return resp

@app.route("/log" , methods=['GET','POST'])
def log():
    error=""
    if request.method=="POST":
        email=request.form['xmail']
        password=request.form['xpass']
        condition=" where (email='" + email + "' or mobile='" + email + "') and  password ='" + password + "'"
        if(dblogin("member",condition)>=1):
            lst= getdata("member",condition)
            session['id']=lst[0][0]
            session['username']=lst[0][1]
            session['email']=lst[0][2]
            session['rollno']=lst[0][3]
            session['mobile']=lst[0][4]
            session['image']=lst[0][5]
            session['login']=True
            session['emailVer']=lst[0][7]
            session['mobVer']=lst[0][8]
            if request.form['xrem'] is not None:
                resp = make_response(render_template('home.html'))
                resp.set_cookie('email', email,60*60*24)
                return resp
            else:
                return render_template("home.html")
        else:
            error="EMail and password is not match"           
            return render_template("login.html",err=error)


@app.route("/reg" , methods=['GET', 'POST'])
def reg():
    error=""
    if request.method=="POST":
        username=request.form['xname']
        email=request.form['xmail']
        rollno=request.form['xroll']
        mobile=request.form['xmob']
        password=request.form['xpass']
        cpassword=request.form['xcpass']
        imagefile=request.files['xfile']
        error=recaptcha.verify()
        if(not(recaptcha.verify())):
            error="Captcha is Not Verify Please Verify Captcha"
        if(password!=cpassword):
            error="Password and Confirm password is not match"
        elif(check("member","email",email)>=1):
            error="Email is already Exist! please choice new Email"
        elif(check("member","mobile",mobile)>=1):
            error="Mobile number is already Exist! Please choice New Mobile number"
        else:
            imagefile.save("static/image/" + secure_filename(imagefile.filename))
            hash_password=bcrypt.generate_password_hash(password)
            qry="insert into member set username='" + username + "', email='" + email + "', rollno='" + rollno + "', mobile='" + mobile + "', password='" + password + "', image='" + imagefile.filename + "', emailVer='0', mobileVer='0'"
            
            if(insert(qry)>=1):
                error="Congratulation ! You Become a member"
            else:
                error="Problem to insert Data Please Contact To Admin"
    return render_template("registration.html",err=error)

@app.route("/forgetpass")
def forgetpass():
    return render_template('forgetpass.html')

@app.route("/chpass")
def chpass():
    return render_template('changepass.html')

@app.route('/changepass',methods=['GET', 'POST'])
def changepass():
    if(request.method=="POST"):
        id=request.form['xid']
        cpassword=request.form['cupass']
        newpassword=request.form['xnpass']
        cnewpassword=request.form['xncpass']
        if(newpassword != cnewpassword):
            data={"mess":"Password and conform is not match", "status":False }   
        else:
            qry=updatepass("member","password", newpassword, id)
            data={"mess":"Successfuly Password Update", "status":True,"query":qry}        
    return render_template('changepass.html',err=data)

@app.route('/code',methods=['GET', 'POST'])
def code():
        if(request.method=="POST"):
            email=request.form['xemail']
            qry="select * from member where email='" + email + "'"
            if(firequery(qry)>=1):
                condition=" where email='" + email + "'"
                lst=getdata("member",condition)
                session['id']=lst[0][0]
                session['email']=lst[0][2]
                verifyForgetCode=random.randint(111111,999999)
                session['code']=verifyForgetCode
                message=" Your forget email verfication code is " + str(verifyForgetCode)
                rece=session['email']
                sender='dimplesotwal@gmail.com'
                msg = Message("Password forget verrfication", sender =sender, recipients = [rece])
                msg.body = message
                mail.send(msg)
                session['forgetMessage']="Verification code send to your Mail Please Verfify and Enter New PAssword"
                return render_template('code.html')
            else:
                session['forgetMessage']="Your Email is not Registred"
                return render_template('forgetpass.html')



@app.route("/codever",methods=['GET', 'POST'])
def codever():
    if(request.method=="POST"):
        textcode=request.form['ncode']
        if(str(textcode)==str(session['code'])):
            error="successfully verified"
            return render_template("newpass.html")     
        else:
            error="Password does not Match. Please try again"
    return render_template("forgetpass.html",err=error)

@app.route("/newpass",methods=['GET', 'POST'])
def newpass():
    error=""
    if(request.method=="POST"):
        password=request.form['npass']
        cnpassword=request.form['cnpass']
        if(password!=cnpassword):
            error="password and confirm password does not match"
        else:
            if(updatepass("member","password",password, session['id'])):
                session['password']=password
                session.pop('id', None)
                session.pop('forgetmessage', None)
                session.pop('email', None)
                error="successfully updated"
            else:
                error="still not updated"
            return render_template("login.html",err=error)

        return render_template('forgetpass.html',err=error)
        


if __name__ == '__main__':
    app.run(debug=True)